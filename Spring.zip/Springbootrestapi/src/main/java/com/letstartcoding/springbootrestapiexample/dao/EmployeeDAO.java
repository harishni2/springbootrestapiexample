package com.letstartcoding.springbootrestapiexample.dao;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.letstartcoding.springbootrestapiexample.module.Employee;
import com.letstartcoding.springbootrestapiexample.repository.EmployeeRepository;


@Service

public class EmployeeDAO {
	
	@Autowired
	EmployeeRepository employeeRepository;
	
	/*save an employee */
	public Employee Save(Employee emp) {
	 return employeeRepository.save(emp);
	}
	
	/*search all employee*/
	 public List<Employee> findAll(){
		 return employeeRepository.findAll();
	 }
	
	/*to get an employee by an id*/
		 public Employee findOne(Long empid) {
			 return employeeRepository.findOne(empid);
		 }
	
	
	/*to delete an employee by an id*/
			 public void delete(Employee emp) {
				  employeeRepository.delete(emp);
			 }

}
